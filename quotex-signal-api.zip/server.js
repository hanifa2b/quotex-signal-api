const express=require("express");
const app=express();
const PORT=process.env.PORT||3000;
app.get("/",(req,res)=>res.send("Quotex Signal API Running"));
app.get("/signal",(req,res)=>{
res.json({trend:"UP",level:"BUY",candle:"GREEN",result:"BUY"});
});
app.listen(PORT,()=>console.log("Server Started"));
