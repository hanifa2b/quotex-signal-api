# Quotex Signal API

Simple Node.js API.
Endpoint: /signal
